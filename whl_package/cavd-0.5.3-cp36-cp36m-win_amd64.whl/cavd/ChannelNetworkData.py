# coding=utf-8
'''
Created on 
@author: hebing
'''
from cavd import LocalEnvirCom
from cavd.netstorage import AtomNetwork
from cavd.channel import Channel
from cavd.get_Symmetry import get_Symmetry
from builtins import None
import numpy as np
from _operator import pos
class CreateChannelNetwork(object):
    def __init__(self):
        self.ChannelNetwork=None
        self.filename=None
        self.moveion=None
    def create_channel_network(self):
        radii,self.migrant_radius,self.migrant_alpha, self.nei_dises = LocalEnvirCom(self.filename,self.moveion)
        self.atmnet = AtomNetwork.read_from_CIF("icsd_245969.cif", radii, True, None)
        self.vornet,self.edge_centers,self.fcs = self.atmnet.perform_voronoi_decomposition(False)
        self.sym_vornet,self.voids = get_Symmetry(self.atmnet, self.vornet)
        self.channels = Channel.findChannels(self.sym_vornet,self.atmnet,0.8,"icsd_16713.net")
    def AddVoids(self):
        self.__postion=np.zeros([len(self.sym_vornet.nodes),3])
        self.__postion=np.zeros([len(self.sym_vornet.nodes),3])
        self.__labels=[]
        self.__radius=np.zeros([len(self.sym_vornet.nodes)])
        for index,node in enumerate(self.sym_vornet.nodes):
            self.__postion[index]=node[2]
            self.__labels.append(node[1])
            self.__radius[index]=node[3]
            
            self.ChannelNetwork.AddAtoms(sitelabel=[str(node[1])],sitetype='Bn',Pos=self.__postion[index],elementsoccupy={'Bn':1.0},radius=self.__radius[index])
    def AddConnection(self):   
        for channel in self.channels:
            for index,conn in enumerate(channel):
                beginid=conn[0]
                endid=conn[1]
                Itradius=conn[3]
                Itpos=conn[4]
                
                beginsite=self.ChannelNetwork.GetSites()[beginid]
                endsite=self.ChannelNetwork.GetSites()[endid]
                self.ChannelNetwork.AddBond(beginsite,endsite)
                self.ChannelNetwork.AddAtoms(sitelabel=[str(index)],sitetype='It',Pos=Itpos,elementsoccupy={'It':1.0},radius=Itradius)
            

class MigrationPath(object):
    def __init__(self, startpos=np.zeros([3]), endpos=np.zeros([3]),startenergy=0,endenergy=0):
        self.pointlist = [startpos,endpos]
        self.energylist=[startenergy,endenergy]
    def AppendPoint(self,pos,energy=0):
        self.pointlist.insert(-1,pos)
        self.energylist.insert(-1,energy)
    def SetPoint(self,index,pos,energy=0):
        self.pointlist[index]=pos
        self.energylist[index]=energy
    def __str__(self):
        return str(self.pointlist)
        
    
    
               
            
