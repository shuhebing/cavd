# coding: utf-8

"""
利用Pymatgen中代码实现的功能。
目前实现的功能：
1.计算离子半径。get_ionic_radii()
"""

import os
import json
from pymatgen.core.structure import Structure
from pymatgen.analysis.local_env import VoronoiNN
from bisect import bisect_left
from pymatgen import Element

file_dir = os.path.dirname(__file__)
rad_file = os.path.join(file_dir, 'ionic_radii.json')
with open(rad_file, 'r') as fp:
    _ion_radii = json.load(fp)

#计算离子半径
def get_ionic_radii(filename):
    """
    Computes ionic radii of elements for all sites in the structure.
    If valence is zero, atomic radius is used.
    """
    radii = []
	#old_cn = []
    cn = []
	
    vnn = VoronoiNN()
    stru = Structure.from_file(filename) 
    def nearest_key(sorted_vals, key):
        i = bisect_left(sorted_vals, key)
        if i == len(sorted_vals):
            return sorted_vals[-1]
        if i == 0:
            return sorted_vals[0]
        before = sorted_vals[i-1]
        after = sorted_vals[i]
        if after-key < key-before:
            return after
        else:
            return before
    
    for i in range(len(stru.sites)):
        site = stru.sites[i]
        if isinstance(site.specie, Element):
            radius = site.specie.atomic_radius
            # Handle elements with no atomic_radius
            # by using calculated values instead.
            if radius is None:
                radius = site.specie.atomic_radius_calculated
            if radius is None:
                raise ValueError(
                        "cannot assign radius to element {}".format(
                        site.specie))
            radii.append(radius)
            continue
            
        el = site.specie.symbol
        oxi_state = int(round(site.specie.oxi_state))

        coord_no = int(round(vnn.get_cn(stru, i)))
        #old_cn.append(coord_no)
        
        try:
            tab_oxi_states = sorted(map(int, _ion_radii[el].keys()))
            oxi_state = nearest_key(tab_oxi_states, oxi_state)
            radius = _ion_radii[el][str(oxi_state)][str(coord_no)]
        except KeyError:
            if vnn.get_cn(stru, i)-coord_no > 0:
                new_coord_no = coord_no + 1
            else:
                new_coord_no = coord_no - 1
            try:
                radius = _ion_radii[el][str(oxi_state)][str(new_coord_no)]
                coord_no = new_coord_no
            except:
                tab_coords = sorted(map(int, _ion_radii[el][str(oxi_state)].keys()))
                new_coord_no = nearest_key(tab_coords, coord_no)
                i = 0
                for val in tab_coords:
                    if  val > coord_no:
                        break
                    i = i + 1
                if i == len(tab_coords):
                    key = str(tab_coords[-1])
                    radius = _ion_radii[el][str(oxi_state)][key]
                elif i == 0:
                    key = str(tab_coords[0])
                    radius = _ion_radii[el][str(oxi_state)][key]
                else:
                    key = str(tab_coords[i-1])
                    radius1 = _ion_radii[el][str(oxi_state)][key]
                    key = str(tab_coords[i])
                    radius2 = _ion_radii[el][str(oxi_state)][key]
                    radius = (radius1+radius2)/2
        #implement complex checks later
        radii.append(radius)
        #cn.append(new_coord_no)
    el = [site.species_string for site in stru.sites]
    radii_dict = dict(zip(el, radii))
    #print("old_cn : ",old_cn)
    #print("new_cn : ",cn)
    return radii_dict
if __name__ == '__main__':
     print(get_ionic_radii("icsd_16713.cif"))
